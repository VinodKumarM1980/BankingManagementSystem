package com.org.loan.model;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document(collection = "loan")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Loan {
	
	private String loanType;
	private double loanAmount;
	private String loanApplyDate;
	private double rateOfInterest;
	private int dourationOfLoan;
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getLoanApplyDate() {
		return loanApplyDate;
	}
	public void setLoanApplyDate(String loanApplyDate) {
		this.loanApplyDate = loanApplyDate;
	}
	public double getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public int getDourationOfLoan() {
		return dourationOfLoan;
	}
	public void setDourationOfLoan(int dourationOfLoan) {
		this.dourationOfLoan = dourationOfLoan;
	}
	
	
	
		
	
}
