package com.org.common.model;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(Include.NON_NULL)
public class ServiceResponse<T> {
	private boolean success;
	private Errors error;
	private T data;
	private String additionalMessage;
	
	
	public boolean isSuccess() {
		return success;
	}


	public void setSuccess(boolean success) {
		this.success = success;
	}


	public Errors getError() {
		return error;
	}


	public void setError(Errors error) {
		this.error = error;
	}


	public T getData() {
		return data;
	}


	public void setData(T data) {
		this.data = data;
	}


	public String getAdditionalMessage() {
		return additionalMessage;
	}


	public void setAdditionalMessage(String additionalMessage) {
		this.additionalMessage = additionalMessage;
	}


	@Data
	@Builder
	public static class Errors {
		private HttpStatus errorCode;
		private String errorMessage;
		
	}
}