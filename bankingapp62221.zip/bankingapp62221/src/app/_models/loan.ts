﻿export class Loan {
    id: string;
    loanType: string;
    loanAmount: string;
    loanApplyDate: string;
    rateOfInterest: string;
    dourationOfLoan: string;
}