﻿export class User {
    id: string;
    name: string;
    username: string;
    password: string;
    guardianname: string;
    address: string;
    email: string;
    gender: string;
    maritial: string;
    mobile: string;
    dob: string;
    acctype:  string;
    token: string;
}