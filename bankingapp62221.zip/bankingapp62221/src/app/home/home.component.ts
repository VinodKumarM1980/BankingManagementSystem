﻿import { Component } from '@angular/core';

import { User } from '@app/_models';
import { Loan } from '@app/_models';


import { AccountService } from '@app/_services';
import {LoanService } from '@app/_services';

@Component({ templateUrl: 'home.component.html' })
export class HomeComponent {
    user: User;
    loan: Loan;

    constructor(private accountService: AccountService,private loanService: LoanService) {
        this.user = this.accountService.userValue;
        this.loan = this.loanService.LoanValue;
    }
}