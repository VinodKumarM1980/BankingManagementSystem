﻿import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '@environments/environment';
import { Loan } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class LoanService {
    private LoanSubject: BehaviorSubject<Loan>;
    public Loan: Observable<Loan>;

    constructor(
        private router: Router,
        private http: HttpClient
    ) {
        this.LoanSubject = new BehaviorSubject<Loan>(JSON.parse(localStorage.getItem('Loan')));
        this.Loan = this.LoanSubject.asObservable();
    }

    public get LoanValue(): Loan {
        return this.LoanSubject.value;
    }


    logout() {
        // remove Loan from local storage and set current Loan to null
        localStorage.removeItem('Loan');
        this.LoanSubject.next(null);
        this.router.navigate(['/account/login']);
    }

    register(Loan: Loan) {
        console.log("loan register")
     ////return this.http.post(`${environment.apiUrl}/user/loan`, Loan);
     //return this.http.post(`${environment.apiUrl}/users/register`, user);
    return this.http.post('http://localhost:8091/customer/applyLoans', Loan);
    }

    getAll() {
        return this.http.get<Loan[]>(`${environment.apiUrl}/Loans`);
    }

    getById(id: string) {
        return this.http.get<Loan>(`${environment.apiUrl}/Loans/${id}`);
    }

    update(id, params) {
        return this.http.put(`${environment.apiUrl}/Loans/${id}`, params)
            .pipe(map(x => {
                // update stored Loan if the logged in Loan updated their own record
                if (id == this.LoanValue.id) {
                    // update local storage
                    const Loan = { ...this.LoanValue, ...params };
                    localStorage.setItem('Loan', JSON.stringify(Loan));

                    // publish updated Loan to subscribers
                    this.LoanSubject.next(Loan);
                }
                return x;
            }));
    }

    delete(id: string) {
        return this.http.delete(`${environment.apiUrl}/Loans/${id}`)
            .pipe(map(x => {
                // auto logout if the logged in Loan deleted their own record
                if (id == this.LoanValue.id) {
                    this.logout();
                }
                return x;
            }));
    }
}