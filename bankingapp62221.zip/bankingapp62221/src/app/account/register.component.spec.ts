import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RegisterComponent } from "./register.component";
import { AccountService, AlertService } from '@app/_services';
import { FormGroup, ReactiveFormsModule, FormsModule, FormBuilder } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { RouterModule } from '@angular/router';
import {Component, DebugElement} from "@angular/core";
import {By} from "@angular/platform-browser"

describe("RegisterComponent", () => {
  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;
  let myService: AccountService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RegisterComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: AccountService, useValue: {} }],
      imports: [ReactiveFormsModule, RouterModule.forRoot([])]
    
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    myService = TestBed.inject(AccountService);
  });

  describe("method1", () => {
    it("test 1", () => {
      expect(component).toBeTruthy();
    });
  });

  describe("method2", () => {
    it("test 2", () => {
      expect(component).toBeTruthy();
    });
  });
})