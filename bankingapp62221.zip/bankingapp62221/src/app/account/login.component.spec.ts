import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { LoginComponent } from "./login.component";
import { FormGroup, ReactiveFormsModule, FormsModule, FormBuilder } from '@angular/forms';
import { AccountService, AlertService } from '@app/_services';
import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { RouterModule } from '@angular/router';
import {Component, DebugElement} from "@angular/core";
import {By} from "@angular/platform-browser"

describe("LoginComponent", () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let myService: AccountService;
  let submitEl: DebugElement;
  let firstNameEl: DebugElement;
  let lastNameEl: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LoginComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA],
      providers: [{ provide: AccountService, useValue: {} }],
      
      imports: [ReactiveFormsModule, RouterModule.forRoot([])]
    
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    myService = TestBed.inject(AccountService);
    submitEl = fixture.debugElement.query(By.css('input[id=btnsubmit]'));
    firstNameEl = fixture.debugElement.query(By.css('input[id=username]'));
    lastNameEl = fixture.debugElement.query(By.css('input[id=password]'));

    const hostElement = fixture.nativeElement;
    const nameInput: HTMLInputElement = hostElement.querySelector('#nameId'); 
  });

 
  it('Component successfully created', () => {
    expect(component).toBeTruthy();
  });

  it('Component successfully created', () => {
    expect(component).toBeTruthy();
  });

  it('should have a title Online Banking  - User Registration', () => {
   
    component = fixture.debugElement.componentInstance;
    expect(component.title).toEqual('Online Banking  - User Registration!');
  });

  it('should perform display binding in HTML template', () => {
    const hostElement = fixture.nativeElement;
    const nameInput: HTMLInputElement = hostElement.querySelector('#username');
    const ageInput: HTMLInputElement = hostElement.querySelector('#password');

    const displayName: HTMLInputElement = hostElement.querySelector('#username1');
    const displayAge: HTMLInputElement = hostElement.querySelector('#password1');
    fixture.detectChanges();

    fixture.whenStable().then(val => {
      nameInput.value = 'Amit Shah';
      ageInput.value = '20';

      nameInput.dispatchEvent(new Event('input'));
      ageInput.dispatchEvent(new Event('input'));

      fixture.detectChanges();
      expect(displayName.textContent).toBe('');
      expect(displayAge.textContent).toBe('');
    });
  });

  
})